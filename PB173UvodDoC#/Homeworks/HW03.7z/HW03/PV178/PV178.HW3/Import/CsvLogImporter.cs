﻿using PV178.HW3.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PV178.HW3.Import
{
    public class CsvLogImporter<T> : ILogImporter<T> where T : class, new()
    {
        private ILogStorage logStorage;
        private string[] properties;
        private bool hasHeaderRow;
        private char columnDelimiter;
        private char textQualifier;
        private string[] headers;

        public CsvLogImporter(ILogStorage logStorage, string[] columnMappings, bool hasHeaderRow, char columnDelimiter, char textQualifier)
        {
            this.logStorage = logStorage;
            this.properties = columnMappings;
            this.hasHeaderRow = hasHeaderRow;
            this.columnDelimiter = columnDelimiter;
            this.textQualifier = textQualifier;

            ///Code below might not be neccessary
            this.headers = new string[columnMappings.Length];
        }

        public List<T> Import()
        {
            List<T> values = new List<T>();
            string fileContent = logStorage.Load();
            string[] lines = Regex.Split(fileContent, "\r\n");
            int i = 0;

            if (fileContent == null)
            {
                //unable to open file
                throw new NotImplementedException();
            }
            if (hasHeaderRow)
            {
                i++;
                int l = 0;
                string[] headr = Regex.Split(lines[0], columnDelimiter.ToString());
                foreach (string item in headr)
                {
                    string result = item.Trim(textQualifier);
                    headers[l++] = result;
                }
            }

            for ( ; i < lines.Length; i++)
            {
                ///Values array for each line
                string[] vals = Regex.Split(lines[i], columnDelimiter.ToString());
                int l = 0;
                T obj = new T();
                bool create = true;


                foreach (string item in vals)
                {
                    if (String.IsNullOrEmpty(item)) {
                        //if "" or null do not add object to list
                        create = false;
                        break;
                    }
                    try
                    {
                        PropertyInfo propertyInfo = obj.GetType().GetProperty(properties[l]);
                        if (propertyInfo.PropertyType == typeof(string))
                        {
                            ///ERASING TEXT QUALIFIER FROM GIVEN STRING
                            string result = item.Trim(textQualifier);
                            propertyInfo.SetValue(obj, Convert.ChangeType(result, propertyInfo.PropertyType), null);
                        }
                        else
                        {
                            propertyInfo.SetValue(obj, Convert.ChangeType(item, propertyInfo.PropertyType), null);
                        }
                    }
                    catch (Exception ex)
                    {
                        //todo english
                        Console.WriteLine("nepodaril osa pretypovat " + ex.Message);
                        throw;
                    }

                    l++;
                }
                if(create)
                    values.Add(obj);
            }

            return values;
        }
    }
}
