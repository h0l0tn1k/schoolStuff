﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PV178.HW3.Storage;
using PV178.HW3.Import;

namespace PV178.HW3
{
    class Program
    {
        static void Main(string[] args)
        {
            TextFileLogStorage tfls = new TextFileLogStorage(@"\\ad.fi.muni.cz\DFS\home\xmatta\_profile\Desktop\xmatta_CSharpProjects\PB173UvodDoC#\Homeworks\HW03\PV178\PV178.HW3\SampleData\CsvFormatLog.csv");
                        
            CsvLogImporter<MyClass> tmp = new CsvLogImporter<MyClass>(tfls, new string[] { "Time", "Login", "Age", "Year", "Name", "Surname" }, 
                                                                        false, ';', '\"');
            List<MyClass> list = tmp.Import();




            foreach (MyClass item in list)
            {
                Console.WriteLine("{0},{1},{2},{3},{4},{5}",item.Time,item.Login,item.Age,item.Year,item.Name,item.Surname);
            }
        }

        public class MyClass
        {
            public DateTime Time { get; set; }
            public string Login { get; set; }
            public int Age { get; set; }
            public int Year { get; set; }
            public string Name { get; set; }
            public string Surname { get; set; }
            
        }
    }
}
