﻿using PV178.HW3.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace PV178.HW3.Export
{
    public class CsvLogExporter<T> : ILogExporter<T> where T : class, new()
    {
        private ILogStorage logStorage;
        private string[] columnMappings;
        private bool hasHeaderRow;
        private char columnDelimiter;
        private char textQualifier;
        public CsvLogExporter(ILogStorage logStorage, string[] columnMappings, bool hasHeaderRow, char columnDelimiter, char textQualifier)
        {
            this.logStorage = logStorage;
            this.columnMappings = columnMappings;
            this.hasHeaderRow = hasHeaderRow;
            this.columnDelimiter = columnDelimiter;
            this.textQualifier = textQualifier;
        }
        public void Export(List<T> data)
        {
            if (logStorage == null)
            {
                throw new ArgumentNullException("logStorage is null");
            }
            string result = "";

            foreach (T item in data)
            {
                for (int i = 0; i < columnMappings.Length; i++)
                {
                }
            }


            throw new NotImplementedException();
        }
    }
}
